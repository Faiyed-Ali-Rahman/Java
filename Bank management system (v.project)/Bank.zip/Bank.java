public abstract class Bank {
    Bank(){
        System.out.println("Default constructor called");
    }
    abstract void write_massage();
    
}
