interface Person
{
    final int id = 10;
    void database();
}
